const axios = require('axios');

const config = require('./config.json');
//configs for requests
const requestConfig = {
  method: 'get',
  url: '',
  headers: {
    'X-API-KEY': config.XAPIKEY,
  },
};

// Helper function that actually does the request
const axiosRequest = async (requestConfig) => {
  return await axios(requestConfig)
    .then((raw) => {
      return raw.data.Response;
    })
    .catch((error) => {
      console.log(
        'There has been an error with the API. Please run the app again!',
      );
    });
};

//searches for players based on a query string returns an object with a display name and membership id
const requestPlayers = async (queryString, platform) => {
  const userUrl = `${config.url}/SearchDestinyPlayer/${platform}/${queryString}`;
  //update the config object to the correct url
  requestConfig['url'] = userUrl;
  return axiosRequest(requestConfig);
};

//returns a players profile for all their characters uses membership id and platform
const requestProfile = async (membershipId, platform) => {
  const profileUrl = `${config.url}/${platform}/Account/${membershipId}/Character/0/Stats/`;
  //update the config object to the correct url
  requestConfig['url'] = profileUrl;
  return axiosRequest(requestConfig);
};

module.exports = {
  requestPlayers,
  requestProfile,
};
